// class CourseModel {
//   final int id;
//   final String courseName;
//   final String institutionName;
//   final String dateCompleted;
//   final String description;
//
//   CourseModel({
//     required this.id,
//     required this.courseName,
//     required this.institutionName,
//     required this.dateCompleted,
//     required this.description,
//   });
//
// }
